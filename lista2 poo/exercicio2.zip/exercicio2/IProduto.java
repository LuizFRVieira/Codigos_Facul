public interface IProduto {
    void calcularFrete(float distancia);
    void calcularPrazoEntrega(float distancia);
}