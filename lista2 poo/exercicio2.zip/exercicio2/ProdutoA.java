public class ProdutoA extends Produto {
    public ProdutoA(String nome, int ID, float valor) {
        super(nome, ID, valor);
    }

    @Override
    public void calcularFrete(float distancia) {
        float taxa = 2000.f;
        float frete = 200.f * distancia / taxa;
        System.out.println("Taxa: = R$ " + taxa);
        System.out.println("Frete: = R$ " + frete + "distanci+taxa ");
    }

    @Override
    public void calcularPrazoEntrega(float distancia) {
        float prazo = distancia / 30;
        System.out.println("Prazo = " + prazo);
    }
}



