public class Produto implements IProduto {
    private String nome;
    private int ID;
    private float valor;

    public Produto(String nome, int ID, float valor) {
        this.nome = nome;
        this.ID = ID;
        this.valor = valor;
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    @Override
    public void calcularFrete(float Distancia) {
    }

    @Override
    public void calcularPrazoEntrega(float distancia) {

    }
}

