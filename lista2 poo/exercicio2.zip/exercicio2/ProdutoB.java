public class ProdutoB extends Produto {
    public ProdutoB(String nome, int ID, float valor) {
        super(nome, ID, valor);
    }

    @Override
    public void calcularFrete(float distancia) {
        float taxa = 5.00f;
        float frete = 50.00f * distancia + taxa;
        System.out.println("Taxa = R$ " + taxa);
        System.out.println("Frete = R$ " + frete + " x distância + taxa");
    }

    @Override
    public void calcularPrazoEntrega(float distancia) {
        float prazo = distancia / 7;
        System.out.println("Prazo = " + prazo);
    }
}