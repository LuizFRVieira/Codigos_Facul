public class Principal {
    public static void main(String[] args) {
        // Criar produtos
        ProdutoA produtoA = new ProdutoA("Produto A", 1, 10.0f);
        ProdutoB produtoB = new ProdutoB("Produto B", 2, 20.0f);

        // Calcular frete e prazo de entrega para ProdutoA
        System.out.println("PRODUTO A");
        System.out.println("calcularFrete()");
        produtoA.calcularFrete(100);
        System.out.println();
        System.out.println("calcularPrazoEntrega()");
        produtoA.calcularPrazoEntrega(100);
        System.out.println();

        // Calcular frete e prazo de entrega para ProdutoB
        System.out.println("PRODUTO B");
        System.out.println("calcularFrete()");
        produtoB.calcularFrete(50);
        System.out.println();
        System.out.println("calcularPrazoEntrega()");
        produtoB.calcularPrazoEntrega(50);
    }
}