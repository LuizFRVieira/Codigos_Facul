public class Principal {
    public static void main(String[] args) {
        // Criar produtos
        ProdutoA produtoA = new ProdutoA("Produto A", 1, 10.0f);
        ProdutoB produtoB = new ProdutoB("Produto B", 2, 20.0f);

        Estoque estoque = new Estoque();

        estoque.adicionarProduto(produtoA);
        estoque.adicionarProduto(produtoB);

        // Exibir estado dos produtos
        System.out.println("Estado do Produto A:");
        exibirEstadoProduto(produtoA);
        System.out.println("Estado do Produto B:");
        exibirEstadoProduto(produtoB);
    }

    private static void exibirEstadoProduto(IProduto produto) {
        System.out.println("Nome: " + produto.getNome());
        System.out.println("ID: " + produto.getID());
        System.out.println("Valor: " + produto.getValor());
    }
}