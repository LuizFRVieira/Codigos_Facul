public class ProdutoB extends Produto {
    public ProdutoB(String nome, int ID, float valor) {
        super(nome, ID, valor);
    }
}