public interface IProduto {
    String getNome();
    int getID();
    float getValor();
    void calcluarFrete();
    void CalcularPrazoEntrega();
}

