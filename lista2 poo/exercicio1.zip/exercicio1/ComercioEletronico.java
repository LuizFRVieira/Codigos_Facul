public class ComercioEletronico {
    private String nome;
    private String proprietario;
    private String enderco;
    private float vendasMensais;
    private int qtdeFuncionarios;
    Estoque estoque;

    public String getNome() {
        return nome;
    }

    public String getProprietario() {
        return proprietario;
    }

    public String getEnderco() {
        return enderco;
    }

    public float getVendasMensais() {
        return vendasMensais;
    }

    public int getQtdeFuncionarios() {
        return qtdeFuncionarios;
    }

    public Estoque getEstoque() {
        return estoque;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setProprietario(String proprietario) {
        this.proprietario = proprietario;
    }

    public void setEnderco(String enderco) {
        this.enderco = enderco;
    }

    public void setVendasMensais(float vendasMensais) {
        this.vendasMensais = vendasMensais;
    }

    public void setQtdeFuncionarios(int qtdeFuncionarios) {
        this.qtdeFuncionarios = qtdeFuncionarios;
    }

    public void setEstoque(Estoque estoque) {
        this.estoque = estoque;
    }
}
