import java.util.ArrayList;
public class Estoque {
    private ArrayList<IProduto> produtos;

    public Estoque() {
        this.produtos = new ArrayList<>();
    }

    public void adicionarProduto(IProduto produto) {
        produtos.add(produto);
    }

    public ArrayList<IProduto> getProdutos() {
        return produtos;
    }

    public void setProdutos(ArrayList<IProduto> produtos) {
        this.produtos = produtos;
    }
}