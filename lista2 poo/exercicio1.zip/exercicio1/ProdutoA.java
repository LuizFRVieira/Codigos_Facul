public class ProdutoA extends Produto {
    public ProdutoA(String nome, int ID, float valor) {
        super(nome, ID, valor);
    }
}