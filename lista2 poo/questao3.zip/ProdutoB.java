public class ProdutoB extends Produto {
    public ProdutoB(String nome, int ID, float valor) {
        super(nome, ID, valor);
    }

    @Override
    public void calcularFrete(float distancia) {
        float taxa = 5.00f;
        float frete = 50.00f * distancia + taxa;
        System.out.println("Taxa = R$ " + taxa);
        System.out.println("Frete = R$ " + frete + " x distância + taxa");
    }

    @Override
    public void calcularPrazoEntrega(float distancia) {
        float prazo = distancia / 7;
        System.out.println("Prazo = " + prazo);
    }

    @Override
    public float calcularImposto(float valor) {
        valor = valor + (valor * 0.22f);
        return valor;
    }

    @Override
    public float calcularLucro(float valor) {
        valor = valor + (valor * 0.87f);
        return valor;
    }

    @Override
    public void atualizarPreco(float atualizacao) {
        setValor(atualizacao);
        System.out.println("preco atualizado, o novo preço é = " + atualizacao + "R$");
    }

    @Override
    public float calcularDespesas(float valor) {
        float despesas = (float) (valor / (1 + 0.70f));
        return despesas;
    }

    @Override
    public void calcularPrecoVendaSugerido(float despesasProducao, float margemLucro) {
        float precoVenda = margemLucro - despesasProducao;

    }
}
