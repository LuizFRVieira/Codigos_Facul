public class Principal {
    public static void main(String[] args) {
        // Criar produtos
        ProdutoA produtoA = new ProdutoA("Produto A", 8754, 58.0f);
        ProdutoB produtoB = new ProdutoB("Produto B", 8965, 89.0f);

        Estoque estoque = new Estoque();

        estoque.adicionarProduto(produtoA);
        estoque.adicionarProduto(produtoB);

        // Exibir estado dos produtos
        System.out.println("Estado do Produto A:");
        exibirEstadoProduto(produtoA);
        System.out.println("Valor do produto A + impostos = " + produtoA.calcularImposto(produtoA.getValor()) + "R$");
        System.out.println("Lucro do Produto A = " + produtoA.calcularLucro(produtoA.calcularImposto(produtoA.getValor())) + "R$");
        System.out.println("Despesas do produto A : " + String.format("%.2f", produtoA.calcularDespesas(produtoA.getValor())) + "R$");
        produtoA.calcularPrecoVendaSugerido(produtoA.calcularDespesas(produtoA.calcularImposto(produtoA.getValor())), produtoA.calcularLucro(produtoA.calcularImposto(produtoA.getValor())));

        System.out.println("\n");

        produtoA.atualizarPreco(120);
        System.out.println("Estado do Produto A apos a troca de valor:");
        exibirEstadoProduto(produtoA);
        System.out.println("Valor do produto A + impostos=" + produtoA.calcularImposto(produtoA.getValor()) + "R$");
        System.out.println("Lucro do Produto A = " + produtoA.calcularLucro(produtoA.calcularImposto(produtoA.getValor())) + "R$");
        System.out.println("Despesas do produto A = " + String.format("%.2f", produtoA.calcularDespesas(produtoA.getValor())) + "R$");
        produtoA.calcularPrecoVendaSugerido(produtoA.calcularDespesas(produtoA.calcularImposto(produtoA.getValor())), produtoA.calcularLucro(produtoA.calcularImposto(produtoA.getValor())));

        System.out.println("\n");

        System.out.println("Estado do Produto B:");
        exibirEstadoProduto(produtoB);
        System.out.println("Valor do produto B + impostos = " + produtoB.calcularImposto(produtoB.getValor()) + "R$");
        System.out.println("Lucro do Produto B = " + produtoB.calcularLucro(produtoB.calcularImposto(produtoB.getValor())) + "R$");
        System.out.println("Despesas do produto B = " + String.format("%.2f", produtoB.calcularDespesas(produtoB.getValor())) + "R$");
        produtoB.calcularPrecoVendaSugerido(produtoB.calcularDespesas(produtoB.calcularImposto(produtoB.getValor())), produtoB.calcularLucro(produtoB.calcularImposto(produtoB.getValor())));

        System.out.println("\n");

        produtoB.atualizarPreco(80);
        System.out.println("Estado do Produto B apos a troca de valor:");
        System.out.println("Valor do produto B + impostos = " + produtoB.calcularImposto(produtoB.getValor()) + "R$");
        System.out.println("Lucro do Produto B = " + produtoB.calcularLucro(produtoB.calcularImposto(produtoB.getValor())) + "R$");
        System.out.println("Despesas do produto B = " + String.format("%.2f", produtoB.calcularDespesas(produtoB.getValor())) + "R$");
        produtoB.calcularPrecoVendaSugerido(produtoB.calcularDespesas(produtoB.calcularImposto(produtoB.getValor())), produtoB.calcularLucro(produtoB.calcularImposto(produtoB.getValor())));


    }

    private static void exibirEstadoProduto(IProduto produto) {
        System.out.println("Nome: " + produto.getNome());
        System.out.println("ID: " + produto.getID());
        System.out.println("Valor: " + produto.getValor() + "R$");
    }
}
