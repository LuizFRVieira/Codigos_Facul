interface IProduto {
    String getNome();

    int getID();

    float getValor();

    void calcularFrete(float distancia);

    void calcularPrazoEntrega(float distancia);

    float calcularImposto(float valor);

    float calcularLucro(float valor);

    void atualizarPreco(float atualizacao);

    float calcularDespesas(float valor);

    void calcularPrecoVendaSugerido(float despesasProducao, float margemLucro);
}