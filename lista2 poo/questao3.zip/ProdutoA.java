class ProdutoA extends Produto {
    public ProdutoA(String nome, int ID, float valor) {
        super(nome, ID, valor);
    }

    @Override
    public void calcularFrete(float distancia) {
        float taxa = 2000.f;
        float frete = 200.f * distancia / taxa;
        System.out.println("Taxa: = R$ " + taxa);
        System.out.println("Frete: = R$ " + frete + "distanci+taxa ");
    }

    @Override
    public void calcularPrazoEntrega(float distancia) {
        float prazo = distancia / 30;
        System.out.println("Prazo = " + prazo);
    }

    @Override
    public float calcularImposto(float valor) {
        valor = valor + (valor * 0.60f);
        return valor;
    }

    @Override
    public float calcularLucro(float valor) {
        valor = valor + (valor * 0.70f);
        return valor;
    }

    @Override
    public void atualizarPreco(float atualizacao) {
        setValor(atualizacao);
        System.out.println("preco atualizado, o novo preço é = " + atualizacao + "R$");

    }

    @Override
    public float calcularDespesas(float valor) {
        float despesas = (float) (valor / (1 + 0.70));
        return despesas;
    }

    @Override
    public void calcularPrecoVendaSugerido(float despesasProducao, float margemLucro) {
        float precoVenda = margemLucro - despesasProducao;
        System.out.println("Preço de venda sugerido = " + String.format("%.2f", precoVenda) + "R$");


    }
}