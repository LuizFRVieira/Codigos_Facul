abstract class Produto implements IProduto {
    private String nome;
    private int ID;
    private float valor;

    public Produto(String nome, int ID, float valor) {
        this.nome = nome;
        this.ID = ID;
        this.valor = valor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }


    public abstract void calcularFrete(float distancia);

    public abstract void calcularPrazoEntrega(float distancia);

    public abstract float calcularImposto(float valor);

    public abstract float calcularLucro(float valor);

    public abstract void atualizarPreco(float atualizacao);

    public abstract float calcularDespesas(float valor);

    public abstract void calcularPrecoVendaSugerido(float despesasProducao, float margemLucro);

}